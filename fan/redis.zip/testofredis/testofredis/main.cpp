
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "hiredis\hiredis.h"
#define NO_QFORKIMPL
#include "Win32_Interop\win32fixes.h"

#pragma comment(lib,"hiredis.lib")
#pragma comment(lib,"Win32_Interop.lib")

#include <iostream>
#include <string>
#include <ctime>

using namespace std;

int sec = 0;

string createDateID(int times, int base = 10000);
string createString(int maxlen);
string createInt(int maxnum);

int main(int argc, char** argv) {
	struct timeval timeout = { 1, 500000 }; // 1.5 seconds
	redisContext* c = redisConnectWithTimeout((char*)"127.0.0.1", 6379, timeout);
	if (c->err) {
		printf("Connection error: %s\n", c->errstr);
	}
	else
	{
		printf("Connection sucessfull\n");

		redisReply* replay;

		string setSQL;
		int times = 8999;

		double max = 0;
		double min = 0;
		double num = 0;
		double avg = 0;

		/*	��������
		for (int i = 0; i < times; i++)
		{

			sec += 1;
			if (sec > 60)
				sec = 0;

			setSQL += "hmset ";
			string temp;
			temp = createDateID(i);
			setSQL += temp;
			setSQL += " field1 ";
			temp = createString(20);
			setSQL += temp;
			setSQL += " field2 ";
			temp = createInt(4);
			setSQL += temp;
			setSQL += " field3 ";
			temp = createInt(4);
			setSQL += temp;
			setSQL += " field4 ";
			temp = createInt(2);
			setSQL += temp;
			setSQL += " field5 ";
			temp = createInt(1);
			setSQL += temp;
			setSQL += " field6 ";
			temp = createString(20);
			setSQL += temp;
			setSQL += " field7 ";
			temp = createInt(3);
			setSQL += temp;
			setSQL += " field8 ";
			temp = createString(20);
			setSQL += temp;

			char *set = (char*)setSQL.data();


			LARGE_INTEGER nFreq;
			LARGE_INTEGER t1;
			LARGE_INTEGER t2;
			double dt;

			QueryPerformanceFrequency(&nFreq);
			QueryPerformanceCounter(&t1);


			replay = (redisReply*)redisCommand(c, set);


			QueryPerformanceCounter(&t2);
			dt = (t2.QuadPart - t1.QuadPart) / (double)nFreq.QuadPart;
			printf("Running time : %f ms\t", dt);
			num += dt;
			if (dt > max)
				max = dt;
			if (dt < min)
				min = dt;


			if (!replay)
			{
				cout << "error..." << endl;
			}
			cout << set << endl;
			setSQL.clear();

		}*/

		//��ѯ����
		string getSQL;
		for (int i = 0; i < 8999; i++)
		{
			string temp;
			getSQL += "hdel ";
			temp = createDateID(i);
			getSQL += temp;
			//getSQL += " field2 ";


			char *get = (char*)getSQL.data();


			LARGE_INTEGER nFreq;
			LARGE_INTEGER t1;
			LARGE_INTEGER t2;
			double dt;

			QueryPerformanceFrequency(&nFreq);
			QueryPerformanceCounter(&t1);


			replay = (redisReply*)redisCommand(c, get);


			QueryPerformanceCounter(&t2);
			dt = (t2.QuadPart - t1.QuadPart) / (double)nFreq.QuadPart;
			num += dt;
			if (dt > max)
				max = dt;
			if (dt < min)
				min = dt;


			if (!replay)
			{
				cout << "error..." << endl;
			}
			cout << get << endl;
			getSQL.clear();
		}

		cout << "max:" << max << endl;
		cout << "min:" << min << endl;
		cout << "avg:" << num / 8999 << endl;
		cout << "num:" << num << endl;

	}
	redisFree(c);
	system("pause");
	return 0;
}

string createDateID(int times, int base)
{
	string DateID;
	int temp = base;
	temp += times;
	DateID = to_string(temp);
	return DateID;
}

string createString(int maxlen)
{
	string String;
	for (int i = 0; i < maxlen; i++)
	{
		if (sec < 10)
			String += "A";
		else if (sec < 20)
			String += "L";
		else if (sec < 30)
			String += "I";
		else if (sec < 40)
			String += "Y";
		else if (sec < 50)
			String += "K";
		else if (sec < 60)
			String += "V";
		else 
			String += "P";
	}
	return String;
}

string createInt(int maxnum)
{
	string String;
	for (int i = 0; i < maxnum; i++)
	{
		if (sec < 10)
			String += "1";
		else if (sec < 20)
			String += "2";
		else if (sec < 30)
			String += "3";
		else if (sec < 40)
			String += "4";
		else if (sec < 50)
			String += "5";
		else if (sec < 60)
			String += "6";
		else
			String += "7";
	}
	return String;
}